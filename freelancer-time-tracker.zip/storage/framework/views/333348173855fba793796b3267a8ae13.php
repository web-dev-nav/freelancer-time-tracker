

<div class="modal" id="edit-log-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Edit Time Log</h3>
            <button class="modal-close" onclick="hideEditLogModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <form id="edit-log-form" class="modal-body">
            <input type="hidden" id="edit-log-id">

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="edit-clock-in-date">
                        <i class="fas fa-calendar"></i>
                        Date
                    </label>
                    <input type="date" id="edit-clock-in-date" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="edit-clock-in-time">
                        <i class="fas fa-clock"></i>
                        Clock In Time
                    </label>
                    <input type="time" id="edit-clock-in-time" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="edit-clock-out-time">
                    <i class="fas fa-clock"></i>
                    Clock Out Time
                </label>
                <input type="time" id="edit-clock-out-time" class="form-control" required>
            </div>

            <div class="form-group">
                <label class="form-label" for="edit-work-description">
                    <i class="fas fa-edit"></i>
                    Work Description
                </label>
                <textarea id="edit-work-description" class="form-control" rows="4"
                         placeholder="Describe what you accomplished during this work session..." required></textarea>
            </div>
        </form>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="hideEditLogModal()">
                Cancel
            </button>
            <button type="submit" form="edit-log-form" class="btn btn-primary">
                <i class="fas fa-save"></i>
                Save Changes
            </button>
        </div>
    </div>
</div>
<?php /**PATH D:\github\freelancer-time-tracker\resources\views/components/timesheet/modals/edit-log.blade.php ENDPATH**/ ?>